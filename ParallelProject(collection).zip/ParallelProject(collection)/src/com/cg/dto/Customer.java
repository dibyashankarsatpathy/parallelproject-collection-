package com.cg.dto;

public class Customer {
	private String customerName;
	private String customerMobileNo;
	private int customerAge;
	private double customerInitialBalance;
	
	public String getName() {
		return customerName;
	}
	public void setName(String name) {
		this.customerName = name;
	}
	
	public String getMobileNo() {
		return customerMobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.customerMobileNo = mobileNo;
	}
	
	public int getAge() {
		return customerAge;
	}
	public void setAge(int age) {
		this.customerAge = age;
	}
	
	public double getInitialBalance() {
		return customerInitialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.customerInitialBalance = initialBalance;
	}
}
