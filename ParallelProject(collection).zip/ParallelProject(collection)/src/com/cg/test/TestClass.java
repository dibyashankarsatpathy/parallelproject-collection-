package com.cg.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.exception.BankAccountException;
import com.cg.service.BankAccountService;
import com.cg.service.BankAccountServiceImpl;

public class TestClass {
	@Test(expected=BankAccountException.class)
    public void test_ValidateName_null() throws BankAccountException{
        BankAccountService service=new BankAccountServiceImpl();
        service.validateName(null);
    }
    
    @Test
    public void test_validateName_v1() throws BankAccountException{
    
        String name="Dibya121";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    
    @Test
    public void test_validateName_v2() throws BankAccountException{
    
        String name="Dibya";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    
    
    @Test
    public void test_validateMobNo_v1() throws BankAccountException{
    
        String mobNo="ABCD91828288";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
}
