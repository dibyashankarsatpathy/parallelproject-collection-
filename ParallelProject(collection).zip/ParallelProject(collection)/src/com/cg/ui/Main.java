package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.Customer;
import com.cg.exception.BankAccountException;
import com.cg.service.BankAccountServiceImpl;

public class Main {
	static BankAccountServiceImpl service = new BankAccountServiceImpl();
	  
	static Scanner sc = new Scanner(System.in);

	static String customerName;
	static String customerMobileNo;
	static int customerAge;
	static double customerAmount;
	static Customer customer;
	public static void main(String args[]) throws BankAccountException{
		

		int ch = 0;
		for(;;){
			System.out.println("1.Add Customer");
			System.out.println("2.Deposit amount");
			System.out.println("3.Withdraw Amount");
			System.out.println("4.Fund transfer");
			System.out.println("5.Check balance");
			System.out.println("6.Exit");
			System.out.println("Please Enter your choice : ");
			ch = sc.nextInt();

			switch(ch){
			case 1 : addCustomer();break;
			case 2 : deposit(); break;					
			case 3 : withdraw(); break;				
			case 4 : fundTransfer();break;
			case 5 : checkBalance(); break;
			case 6 : exit();break;
			default : System.out.println("Invalid input!");
			}

		}

	}
	private static void exit() {
		System.out.println("Thank You!");
		System.exit(0);

	}
	private static int checkBalance() throws BankAccountException {

		System.out.println("Enter the moible number to check balance");
		customerMobileNo = sc.next();
		if(!service.validateAccount(customerMobileNo)){
			System.out.println("Mobile Number not found!");
			return 0;
		}


		System.out.println("Your Current Amount is "+service.checkBalance(customerMobileNo)+"Rupees");
		return 0;

	}
	private static int fundTransfer() throws BankAccountException {
		String mobileNoReciever;
		System.out.println("Please Enter your mobile number : ");
		customerMobileNo = sc.next();

		System.out.println("Enter the amount you want to transfer : ");
		customerAmount = sc.nextDouble();

		System.out.println("Enter receivers mobile number : ");
		mobileNoReciever = sc.next();
		if(customerMobileNo.equals(mobileNoReciever)){								
			System.out.println("Both numbers are same!");
			return 0;
		}
		if(service.validateMoileNo(customerMobileNo) && service.validateMoileNo(mobileNoReciever) && service.validateAmount(customerAmount)){
			if(service.validateAccount(mobileNoReciever) && service.validateAccount(customerMobileNo))
				service.fundTransfer(customerMobileNo, mobileNoReciever, customerAmount);
		}

		return 0;


	}
	private static int withdraw() throws BankAccountException {
		System.out.println("Enter your mobile number : ");
		customerMobileNo = sc.next();

		System.out.println("Enter the amount you want to withdraw : ");
		customerAmount = sc.nextDouble();
		if(service.validateMoileNo(customerMobileNo) && service.validateAmount(customerAmount)){
			if(!service.validateAccount(customerMobileNo))
				return 0;
		}
		service.withdraw(customerMobileNo, customerAmount);
		return 0;

	}
	private static int deposit() throws BankAccountException {
		System.out.println("Enter your mobile number : ");
		customerMobileNo = sc.next();

		System.out.println("Enter the amount you want to deposit");
		customerAmount = sc.nextDouble();
		if(service.validateMoileNo(customerMobileNo)&& service.validateAmount(customerAmount)){
			if(!service.validateAccount(customerMobileNo))
				return 0;
		}
		service.deposit(customerMobileNo, customerAmount);
		return 0;

	}
	private static int addCustomer() throws BankAccountException {
		customer = new Customer();						

		System.out.println("Enter customer name : ");
		customerName = sc.next();
		if(!service.validateName(customerName))
		{
			System.err.println("Invalid Name!");
			return 0;
		}
		System.out.println("Enter your mobile no. : ");
		customerMobileNo = sc.next();
		if(!service.validateMoileNo(customerMobileNo))
		{
			System.err.println("Mobile Number is not valid Please try again");
			return 0;
		}
		else if(service.validateAccount(customerMobileNo))
		{
			System.err.println("Account already exist with this number!");
			return 0;
		}
		else
			System.out.println("Enter age : ");
		customerAge = sc.nextInt();
		if(service.validateAge(customerAge))
			System.out.println("Enter initial amount : ");
		customerAmount = sc.nextDouble();
		if(!service.validateAmount(customerAmount))
		{
			System.err.println("Invalid Amount!");
			return 0;
		}
		else{	
			customer.setName(customerName);
			customer.setMobileNo(customerMobileNo);
			customer.setAge(customerAge);
			customer.setInitialBalance(customerAmount);

			service.createAccount(customer);

			System.out.println("Customer added");
		}
		return 0;
	}
}
